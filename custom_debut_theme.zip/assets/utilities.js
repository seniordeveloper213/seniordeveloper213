"use strict";

Shopify.contentCreator.accordion = {
  init: function init() {
    var $accordionHeading = $('.accordion > dt > a, [data-cc-accordion] > dt > a');
    $('.accordion > dd, [data-cc-accordion] > dd').attr('aria-hidden', true);
    $accordionHeading.attr('aria-expanded', false);
    $accordionHeading.on('click', function () {
      var state = $(this).attr('aria-expanded') === 'false' ? true : false;
      $(this).attr('aria-expanded', state);
      $(this).parent().next().attr('aria-hidden', !state);
      return false;
    });
    $accordionHeading.on('keydown', function (event) {
      var keyCode = event.keyCode || e.which;

      if (keyCode === 13) {
        $(this).trigger('activate');
      }
    });
  },
  unload: function unload() {
    $('.accordion > dt > a, [data-cc-accordion] > dt > a').off('click activate');
    $('.accordion > dt > a, [data-cc-accordion] > dt > a').off('keydown');
  }
};
Shopify.contentCreator.slideshow = {
  init: function init() {
    //backwards compatibility with flexslider
    $('.slider, .flexslider').find('li').unwrap();
    $('.slider, .flexslider').flickity({
      pageDots: true,
      lazyLoad: 2
    });
  }
};
Shopify.theme.animation = {
  init: function init() {
    $('[data-scroll-class]').waypoint(function () {
      var animationClass = $(this.element).data('scroll-class');
      $(this.element).addClass('animated').addClass(animationClass);
    }, {
      offset: '70%'
    });
  },
  slideTransition: function slideTransition($el, animationName, callback) {
    $el.parents('.flickity-enabled').find('.animated').removeClass('animated ' + animationName);
    $el.addClass('animated').addClass(animationName);
  },
  unload: function unload($target) {
    $target.data('scroll-class', '');
  }
};
var deferred = {};
Shopify.theme.asyncView = {
  /**
   * Load the template given by the provided URL into the provided
   * view
   *
   * @param {string} url - The url to load.
   * @param {string} view - The view to load into.
   * @param {object} options - Config options.
   * @param {string} options.hash - A hash of the current page content.
   */
  load: function load(url, view) {
    var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    var data;

    if (url in deferred) {
      return deferred[url];
    }

    var $deferred = $.Deferred();
    deferred[url] = $deferred;

    if (options.hash) {
      data = sessionStorage.getItem(url);

      if (data) {
        var deserialized = JSON.parse(data);

        if (options.hash === deserialized.options.hash) {
          delete deferred[url];
          return $deferred.resolve(deserialized).promise();
        }
      }
    } // NOTE The $.ajax request has the cache option set to false.
    // This is to prevent certain browsers from returning cached
    // versions of the url we are requesting.
    // See this PR for more info: https://github.com/pixelunion/shopify-asyncview/pull/4


    $.ajax({
      url: url,
      cache: false,
      data: "view=".concat(view),
      dataType: 'html',
      headers: {
        'cache-control': 'no-cache'
      },
      success: function success(response) {
        var el = document.createElement('div');
        el.innerHTML = response;
        var responseOptions = JSON.parse(el.querySelector('[data-options]').innerHTML);
        var htmls = el.querySelectorAll('[data-html]');
        var html = {};

        if (htmls.length === 1 && htmls[0].getAttribute('data-html') === '') {
          html = htmls[0].innerHTML;
        } else {
          for (var _i = 0; _i < htmls.length; _i++) {
            html[htmls[_i].getAttribute('data-html')] = htmls[_i].innerHTML;
          }
        }

        if (options.hash) {
          try {
            sessionStorage.setItem(url, JSON.stringify({
              options: responseOptions,
              html: html
            }));
          } catch (error) {
            console.error(error);
          }
        }

        delete deferred[url];
        return $deferred.resolve({
          options: responseOptions,
          html: html
        });
      },
      error: function error() {
        delete deferred[url];
        return $deferred.reject();
      }
    });
    return $deferred.promise();
  }
};

Shopify.theme.addImageDimension = function (imageUrl, size) {
  var insertPosition = imageUrl.lastIndexOf(".");
  return imageUrl.substring(0, insertPosition) + size + imageUrl.substring(insertPosition);
};

Shopify.theme.breadcrumbs = {
  init: function init(pages) {
    // Show pagination if number of pages is greater than 1
    if (pages > 1) {
      var breadcrumbSpan = document.querySelector('[data-breadcrumb-text]');
      var currentPage = document.querySelector('.paginate').dataset.currentPage ? document.querySelector('.paginate').dataset.currentPage : 1;
      var totalPages = document.querySelector('.paginate').dataset.paginatePages;
      document.querySelector('.js-breadcrumb-text').classList.remove('is-hidden');
      breadcrumbSpan.innerHTML = "".concat(Shopify.translation.page_text, " ").concat(currentPage, " ").concat(Shopify.translation.of_text, " ").concat(totalPages);
    }
  },
  unload: function unload($target) {
    document.querySelector('.js-breadcrumb-text').classList.add('is-hidden');
  }
};
Shopify.theme.disclosure = {
  enable: function enable() {
    var $disclosure = $('[data-disclosure]');
    var $toggle = $('[data-disclosure-toggle]');
    var $disclosureWrap = $('.disclosure__list-wrap');
    var $mobileMenuDisclosureList = $('[data-disclosure-list]'); // Check if current opened menu is offscreen

    function checkOffScreen($openedToggle) {
      if ($openedToggle.siblings('.disclosure__list-wrap').is(':off-right')) {
        $openedToggle.siblings('.disclosure__list-wrap').addClass('disclosure--left');
      }
    }

    function closeDisclosures(ignoreTarget, currentTarget) {
      if (ignoreTarget === true) {
        $toggle.not(currentTarget).removeClass('is-clicked');
        $toggle.not(currentTarget).attr('aria-expanded', 'false');
      } else {
        $toggle.removeClass('is-clicked');
        $toggle.attr('aria-expanded', 'false');
      }

      $disclosureWrap.removeClass('disclosure--left');
    } // Close menus on ESC


    $('body').on('keyup', function (e) {
      if (e.which == '27') {
        closeDisclosures();
      }
    }); // Close menus on hoverout

    $disclosure.on('mouseleave', function (e) {
      closeDisclosures();
    }); // Close menus on hoverout

    $disclosure.find('.disclosure-list__item:last-child').on('focusout', function (e) {
      closeDisclosures();
    }); // On click/focus event for toggling options

    $toggle.on('mouseenter focus', function (e) {
      // Close all other menus
      closeDisclosures(true, this);
      var $target = $(e.currentTarget);
      $target.attr('aria-expanded', 'true').addClass('is-clicked');
      checkOffScreen($target);
    }); // Mobile toggle logic

    $mobileMenuDisclosureList.on('touchstart', function (e) {
      var $target = $(e.currentTarget);
      $target.parents('.disclosure').addClass('is-clicked');
      closeDisclosures(true, this);

      if ($target.hasClass('is-clicked') == false) {
        $target.attr('aria-expanded', 'true').addClass('is-clicked');
        checkOffScreen($target);
      } else {
        $target.attr('aria-expanded', 'false').removeClass('is-clicked');
        $disclosureWrap.removeClass('disclosure--left');
      }
    });
    $mobileMenuDisclosureList.on('focusout', function (e) {
      closeDisclosures(true, this);
    }); // Mobile form submitting

    $mobileMenuDisclosureList.on('change', function (e) {
      if (Shopify.media_queries.medium.matches || !/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        var $target = $(e.currentTarget);
        var selectedValue = e.currentTarget.value;
        var disclosureInput = $target.parents('.selectors-form__item').find('[data-disclosure-input]');
        var selectorForm = $target.parents('.selectors-form');

        if (!$target.hasClass('custom-currency')) {
          disclosureInput.val(selectedValue);
          selectorForm.submit();
        } else {
          $target.trigger('click');
        }
      }
    });
  },
  unload: function unload() {
    $('[data-disclosure]').off();
    $('[data-disclosure-toggle]').off();
    $('.disclosure__list-wrap').off();
  }
};

Shopify.theme.dropdownMenu = function () {
  // Grab menu items
  var menuItems = $('.navbar-link'); // Grab dropdowns

  var dropdowns = $('.navbar-dropdown'); // Grab megamenus

  var megamenus = $('.has-mega-menu'); // Listen for enter key

  menuItems.each(function (index, item) {
    var itemVisited = false;
    $(item).on('keydown', function (e) {
      // Check if enter key
      if (e.which === 13) {
        // Prevent it from going to the link
        if (itemVisited === false) {
          e.preventDefault();
        } // Show dropdown


        $(this).closest('.navbar-item').addClass('show-dropdown'); // Reset itemVisited so that they can visit the link

        itemVisited = true;
      }
    });
    $(item).closest('.navbar-item').on('focusout', function (e) {
      if ($(this).find(e.relatedTarget).length === 0) {
        $(item).closest('.navbar-item').removeClass('show-dropdown');
      }
    });
  }); // Listen for enter key

  dropdowns.each(function (index, item) {
    var itemVisited = false;
    $(item).on('keydown', function (e) {
      // Check if enter key
      if (e.which === 13) {
        // Prevent it from going to the link
        if (itemVisited === false) {
          e.preventDefault();
        }

        if ($(this).find('.has-submenu').length > 0) {
          $(this).addClass('show-nested-dropdown');
        } // Reset itemVisited so that they can visit the link


        itemVisited = true;
      }
    });
  }); // Listen for enter key

  megamenus.each(function (index, item) {
    var itemVisited = false;
    $(item).on('keydown', function (e) {
      // Check if enter key
      if (e.which === 13) {
        // Prevent it from going to the link
        if (itemVisited === false) {
          e.preventDefault();
        } // Show megamenu


        $(this).find('.mega-menu').addClass('mega-menu--show'); // Reset itemVisited so that they can visit the link

        itemVisited = true;
      }
    }); // Hide mega menu on focusout

    $(item).on('focusout', function (e) {
      if ($(item).find(e.relatedTarget).length === 0) {
        $(item).find('.mega-menu').removeClass('mega-menu--show');
      }
    });
  });
};

Shopify.theme.newsletterAjaxForm = {
  init: function init() {
    // Selectors
    var $ajaxForm = $('.newsletter-form__wrapper .contact-form');
    $ajaxForm.each(function () {
      var $form = $(this);
      $form.on('submit', function (e) {
        if ($('input[name="challenge"]', $form).val() !== "true") {
          $.ajax({
            type: $form.attr('method'),
            url: $form.attr('action'),
            data: $form.serialize(),
            success: function success(data) {
              $form.fadeOut("slow", function () {
                $form.prev('.form__success-message').html(Shopify.translation.newsletter_form_success);
              });
            },
            error: function error(data) {
              $('input[name="challenge"]', $form).val('true');
              $form.submit();
            }
          });
          e.preventDefault();
        }
      });
    });
  },
  unload: function unload() {
    var $ajaxForm = $('.newsletter-form__wrapper .contact-form');
    var $submitButton = $ajaxForm.find(':submit');
    $submitButton.off();
  }
};

Shopify.theme.getSectionData = function ($section) {
  var sectionId = $section.attr('id').replace('shopify-section-', '');
  var $dataEl = $section.find('[data-section-data][data-section-id=' + sectionId + ']').first();
  if (!$dataEl) return {}; // Load data from attribute, or innerHTML

  var data = $dataEl.data('section-data') || $dataEl.html();

  try {
    return JSON.parse(data);
  } catch (error) {
    console.warn("Sections: invalid section data found. ".concat(error.message));
    return {};
  }
};

Shopify.theme.infiniteScroll = {
  init: function init() {
    this.defaults = {
      grid: '[data-load-more--grid]',
      gridItems: '[data-load-more--grid-item]'
    };
    $('body').on('click', '[data-load-more]', function (e) {
      e.preventDefault();
      var $button = $(this);
      var url = $button.attr('href');
      Shopify.theme.infiniteScroll.loadNextPage(url, $button);
    });
    $('body').on('click', '[data-load-more-infinite]', function (e) {
      Shopify.theme.infiniteScroll.enableInfinite();
      $(this).remove(); // Prevent link from going to next page

      e.stopPropagation();
      return false;
    });

    if ($('[data-load-infinite-scroll]').length) {
      Shopify.theme.infiniteScroll.enableInfinite();
    }
  },
  loadNextPage: function loadNextPage(url, $button) {
    var _this = this;

    $.ajax({
      type: 'GET',
      dataType: 'html',
      url: url,
      beforeSend: function beforeSend() {
        $button.addClass('is-loading');
      },
      success: function success(data) {
        $button.removeClass('is-loading');
        var thumbnails = $(data).find(_this.defaults.gridItems);
        var loadMoreButtonUrl = $(data).find('[data-load-more]').attr('href');
        $('[data-load-more]').attr('href', loadMoreButtonUrl);
        $(_this.defaults.grid).first().append(thumbnails); // When there are no additional pages, hide load more button

        if (typeof loadMoreButtonUrl == 'undefined') {
          $('[data-load-more]').addClass('is-hidden');
        }
      },
      error: function error(x, t, m) {
        console.log(x);
        console.log(t);
        console.log(m);
        location.replace(location.protocol + '//' + location.host + filterURL);
      }
    });
  },
  enableInfinite: function enableInfinite() {
    var infiniteScroll = new Waypoint.Infinite({
      element: $(this.defaults.grid)[0],
      items: '[data-load-more--grid-item]',
      more: '[data-load-infinite]',
      loadingClass: 'loading-in-progress',
      onBeforePageLoad: function onBeforePageLoad() {
        $('[data-load-infinite]').removeClass('is-hidden');
      },
      onAfterPageLoad: function onAfterPageLoad(data) {}
    });
  },
  unload: function unload() {
    $('[data-load-more]').off();
    $('[data-load-infinite]').off();
  }
};

Shopify.theme.flickityIosFix = function () {
  var touchingCarousel = false,
      touchStartCoords;
  document.body.addEventListener('touchstart', function (e) {
    if (e.target.closest('.flickity-slider')) {
      touchingCarousel = true;
    } else {
      touchingCarousel = false;
      return;
    }

    touchStartCoords = {
      x: e.touches[0].pageX,
      y: e.touches[0].pageY
    };
  });
  document.body.addEventListener('touchmove', function (e) {
    if (!(touchingCarousel && e.cancelable)) {
      return;
    }

    var moveVector = {
      x: e.touches[0].pageX - touchStartCoords.x,
      y: e.touches[0].pageY - touchStartCoords.y
    };
    if (Math.abs(moveVector.x) > 7) e.preventDefault();
  }, {
    passive: false
  });
};

Shopify.theme.loadScript = function (name, url, callback) {
  if (Shopify.theme[name]) {
    callback;
  } else {
    $.ajax({
      url: url,
      dataType: 'script',
      success: callback,
      async: false
    });
  }
};
/*============================================================================
Swatch options - second and third swatch 'sold-out' will update based on availability of previous options selected
==============================================================================*/


Shopify.theme.updateOptionsInSelector = function (selectorIndex, parent) {
  switch (selectorIndex) {
    case 0:
      var key = 'root';
      var selector = $(parent + ' .single-option-selector:eq(0)');
      break;

    case 1:
      var key = $(parent + ' .single-option-selector:eq(0)').val();
      var selector = $(parent + ' .single-option-selector:eq(1)');
      break;

    case 2:
      var key = $(parent + ' .single-option-selector:eq(0)').val();
      key += ' / ' + $(parent + ' .single-option-selector:eq(1)').val();
      var selector = $(parent + ' .single-option-selector:eq(2)');
  }

  var availableOptions = Shopify.optionsMap[key];
  $(parent + ' .swatch[data-option-index="' + selectorIndex + '"] .swatch-element').each(function () {
    if ($.inArray($(this).attr('data-value'), availableOptions) !== -1) {
      $(this).removeClass('soldout').find(':radio').removeAttr('disabled', 'disabled').removeAttr('checked');
    } else {
      $(this).addClass('soldout').find(':radio').removeAttr('checked').attr('disabled', 'disabled');
    }
  });
};

Shopify.linkOptionSelectors = function (product, parent) {
  // Building our mapping object.
  Shopify.optionsMap = {};

  for (var i = 0; i < product.variants.length; i++) {
    var variant = product.variants[i];

    if (variant.available) {
      // Gathering values for the 1st drop-down.
      Shopify.optionsMap['root'] = Shopify.optionsMap['root'] || [];
      Shopify.optionsMap['root'].push(variant.option1);
      Shopify.optionsMap['root'] = Shopify.uniq(Shopify.optionsMap['root']); // Gathering values for the 2nd drop-down.

      if (product.options.length > 1) {
        var key = variant.option1;
        Shopify.optionsMap[key] = Shopify.optionsMap[key] || [];
        Shopify.optionsMap[key].push(variant.option2);
        Shopify.optionsMap[key] = Shopify.uniq(Shopify.optionsMap[key]);
      } // Gathering values for the 3rd drop-down.


      if (product.options.length === 3) {
        var key = variant.option1 + ' / ' + variant.option2;
        Shopify.optionsMap[key] = Shopify.optionsMap[key] || [];
        Shopify.optionsMap[key].push(variant.option3);
        Shopify.optionsMap[key] = Shopify.uniq(Shopify.optionsMap[key]);
      }
    }
  } // Update options right away.


  Shopify.theme.updateOptionsInSelector(0, parent);
  if (product.options.length > 1) Shopify.theme.updateOptionsInSelector(1, parent);
  if (product.options.length === 3) Shopify.theme.updateOptionsInSelector(2, parent); // When there is an update in the first dropdown.

  $(parent + " .single-option-selector:eq(0)").change(function () {
    Shopify.theme.updateOptionsInSelector(1, parent);
    if (product.options.length === 3) Shopify.theme.updateOptionsInSelector(2, parent);
    return true;
  }); // When there is an update in the second dropdown.

  $(parent + " .single-option-selector:eq(1)").change(function () {
    if (product.options.length === 3) Shopify.theme.updateOptionsInSelector(2, parent);
    return true;
  });
};

Shopify.theme.applyMasonry = function (selector, gutterSize) {
  var $galleryWrapper = $('.gallery-type--masonry');

  if ($galleryWrapper.length > 0) {
    $galleryWrapper.imagesLoaded().progress(function () {
      $galleryWrapper.isotope({
        layoutMode: 'masonry',
        itemSelector: selector,
        percentPosition: true,
        masonry: {
          columnWidth: selector,
          gutter: gutterSize
        }
      });
    });
  }
};

Shopify.theme.applyHorizontalMasonry = function () {
  var $galleryWrapper = $('.gallery-type--horizontal-masonry');
  $galleryWrapper.find('.gallery__item').each(function (e) {
    var wrapper = $(this);
    var imgWidth, imgHeight;
    setTimeout(function () {
      imgWidth = wrapper.find('img').width();
      imgHeight = wrapper.find('img').height();
      wrapper.css("flex-basis", imgWidth * 200 / imgHeight);
      wrapper.css("flex-grow", imgWidth * 200 / imgHeight);
      wrapper.find("i").css("padding-bottom", imgHeight / imgWidth * 100 + '%');
    }, 100);
  });
};

Shopify.theme.mobileMenu = {
  init: function init() {
    this.$mobileMenuToggle = $('[data-show-mobile-menu]');
    this.$mobileMenuIcon = $('.mobile-menu__toggle-icon');
    this.$mobileDropDownToggle = $('.mobile-menu .close-dropdown');
    $('body').on('click', '[data-show-mobile-menu="false"]', function () {
      Shopify.theme.mobileMenu.open();
    });
    $('body').on('click', '[data-show-mobile-menu="true"]', function () {
      Shopify.theme.mobileMenu.close();
    });

    if (Shopify.theme.jsHeader.enable_sticky === true) {
      this.enableSticky();
    }
  },
  open: function open() {
    //Get current position on page
    var currentScrollPosition = window.scrollY;
    $('body').attr('data-current-position', currentScrollPosition); // Calculate height of mobile content area

    var announcementHeight = 0;
    var mobileHeaderHeight = parseInt($('.mobile-header').height());

    if (typeof Shopify.theme.jsAnnouncementBar !== 'undefined' && Shopify.theme.jsAnnouncementBar.enable_sticky) {
      announcementHeight = Shopify.theme.jsAnnouncementBar.getAnnouncementHeight();
    }

    $('.mobile-menu').css({
      height: "calc(100vh - ".concat(mobileHeaderHeight + announcementHeight, "px)")
    });
    this.$mobileMenuIcon.addClass('is-active');
    $('[data-show-mobile-menu]').attr('data-show-mobile-menu', true);

    if (typeof Shopify.theme.jsAjaxCart !== 'undefined') {
      Shopify.theme.jsAjaxCart.hideMiniCart();
      Shopify.theme.jsAjaxCart.hideDrawer();
    } //Set delay on menu open to get proper page position


    setTimeout(function () {
      $('body').addClass('mobile-menu--opened');
    }, 10);
  },
  close: function close() {
    $('body').removeClass('mobile-menu--opened'); // Once mobile menu is closed, return back to previous position on page

    var lastScrollPosition = $('body').data('current-position');
    window.scrollTo(0, lastScrollPosition);
    this.$mobileMenuIcon.removeClass('is-active');
    $('[data-show-mobile-menu]').attr('data-show-mobile-menu', false);
  },
  enableSticky: function enableSticky() {
    Shopify.theme.jsHeader.disableSticky();
    var $stickyEl = $('#mobile-header');
    var offset = 0;

    if (typeof Shopify.theme.jsAnnouncementBar !== 'undefined' && Shopify.theme.jsAnnouncementBar.enable_sticky) {
      offset = Shopify.theme.jsAnnouncementBar.getAnnouncementHeight();
    }

    $stickyEl.addClass('sticky--enabled');
    $stickyEl.sticky({
      wrapperClassName: 'header-sticky-wrapper',
      zIndex: 40,
      topSpacing: offset
    }).on('sticky-start', function () {
      var headerheight = $('#mobile-header').height();
      var annoucementHeight = $('.announcement-sticky-wrapper').height();
      var totalHeight = headerheight + annoucementHeight;
      $stickyEl.parent().parent().find('.search-overlay').addClass('sticky-search').css('top', totalHeight + 'px');
    }).on('sticky-end', function () {
      $stickyEl.parent().parent().find('.search-overlay').removeClass('sticky-search').css('top', '100%'); // Safety timeout for logo width transition which can throw calculated height off

      setTimeout(function () {
        $stickyEl.sticky('update');
      }, 250);
      $stickyEl.find('.sticky-menu-wrapper').removeClass('is-visible');
    });
  },
  disableSticky: function disableSticky() {
    var $stickyEl = $('#mobile-header');
    $stickyEl.unstick();
    $stickyEl.removeClass('sticky--enabled');
    setTimeout(function () {
      $('.header-sticky-wrapper').css('height', 'auto');
    }, 250);
  },
  unload: function unload($section) {
    $('[data-mobilemenu-toggle]').off();
    $('.mobile-menu__toggle-icon').off();
    $('.mobile-menu .close-dropdown').off();
    this.disableSticky();
  }
};
Shopify.theme.objectFitImages = {
  init: function init() {
    objectFitImages();

    if (Shopify.theme_settings.image_loading_style == 'color') {
      this.calculateAspectRatio();
    }
  },
  calculateAspectRatio: function calculateAspectRatio() {
    // Get list of image-element__wrap's to calculate
    var imageWrap = document.querySelectorAll('[data-calculate-aspect-ratio]'); // Iterate through list

    for (var _i2 = 0; _i2 < imageWrap.length; _i2++) {
      var image = imageWrap[_i2].firstElementChild; // Calculate aspect ratio based off of original width & height

      var aspectRatio = image.getAttribute('width') / image.getAttribute('height'); // Calculate proper width based off of aspect ratio

      var aspectWidth = image.height * aspectRatio; // Apply width to image wrap

      imageWrap[_i2].style.maxWidth = "".concat(Math.floor(aspectWidth), "px");
    } // Remove background color once loaded


    document.addEventListener('lazyloaded', function (e) {
      e.srcElement.parentNode.style.background = 'none';
    });
  },
  unload: function unload() {}
};
/* option_selection.js */

function floatToString(t, e) {
  var o = t.toFixed(e).toString();
  return o.match(/^\.\d+/) ? "0" + o : o;
}

if ("undefined" == typeof Shopify) var Shopify = {};
Shopify.each = function (t, e) {
  for (var o = 0; o < t.length; o++) {
    e(t[o], o);
  }
}, Shopify.map = function (t, e) {
  for (var o = [], i = 0; i < t.length; i++) {
    o.push(e(t[i], i));
  }

  return o;
}, Shopify.arrayIncludes = function (t, e) {
  for (var o = 0; o < t.length; o++) {
    if (t[o] == e) return !0;
  }

  return !1;
}, Shopify.uniq = function (t) {
  for (var e = [], o = 0; o < t.length; o++) {
    Shopify.arrayIncludes(e, t[o]) || e.push(t[o]);
  }

  return e;
}, Shopify.isDefined = function (t) {
  return "undefined" == typeof t ? !1 : !0;
}, Shopify.getClass = function (t) {
  return Object.prototype.toString.call(t).slice(8, -1);
}, Shopify.extend = function (t, e) {
  function o() {}

  o.prototype = e.prototype, t.prototype = new o(), t.prototype.constructor = t, t.baseConstructor = e, t.superClass = e.prototype;
}, Shopify.locationSearch = function () {
  return window.location.search;
}, Shopify.locationHash = function () {
  return window.location.hash;
}, Shopify.replaceState = function (t) {
  window.history.replaceState({}, document.title, t);
}, Shopify.urlParam = function (t) {
  var e = RegExp("[?&]" + t + "=([^&#]*)").exec(Shopify.locationSearch());
  return e && decodeURIComponent(e[1].replace(/\+/g, " "));
}, Shopify.newState = function (t, e) {
  var o;
  return o = Shopify.urlParam(t) ? Shopify.locationSearch().replace(RegExp("(" + t + "=)[^&#]+"), "$1" + e) : "" === Shopify.locationSearch() ? "?" + t + "=" + e : Shopify.locationSearch() + "&" + t + "=" + e, o + Shopify.locationHash();
}, Shopify.setParam = function (t, e) {
  Shopify.replaceState(Shopify.newState(t, e));
}, Shopify.Product = function (t) {
  Shopify.isDefined(t) && this.update(t);
}, Shopify.Product.prototype.update = function (t) {
  for (var property in t) {
    this[property] = t[property];
  }
}, Shopify.Product.prototype.optionNames = function () {
  return "Array" == Shopify.getClass(this.options) ? this.options : [];
}, Shopify.Product.prototype.optionValues = function (t) {
  if (!Shopify.isDefined(this.variants)) return null;
  var e = Shopify.map(this.variants, function (e) {
    var o = "option" + (t + 1);
    return void 0 == e[o] ? null : e[o];
  });
  return null == e[0] ? null : Shopify.uniq(e);
}, Shopify.Product.prototype.getVariant = function (t) {
  var e = null;
  return t.length != this.options.length ? e : (Shopify.each(this.variants, function (o) {
    for (var i = !0, r = 0; r < t.length; r++) {
      var n = "option" + (r + 1);
      o[n] != t[r] && (i = !1);
    }

    return 1 == i ? void (e = o) : void 0;
  }), e);
}, Shopify.Product.prototype.getVariantById = function (t) {
  for (var e = 0; e < this.variants.length; e++) {
    var o = this.variants[e];
    if (t == o.id) return o;
  }

  return null;
}, Shopify.money_format = "${{amount}}", Shopify.formatMoney = function (t, e) {
  function o(t, e) {
    return "undefined" == typeof t ? e : t;
  }

  function i(t, e, i, r) {
    if (e = o(e, 2), i = o(i, ","), r = o(r, "."), isNaN(t) || null == t) return 0;
    t = (t / 100).toFixed(e);
    var n = t.split("."),
        a = n[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1" + i),
        s = n[1] ? r + n[1] : "";
    return a + s;
  }

  "string" == typeof t && (t = t.replace(".", ""));
  var r = "",
      n = /\{\{\s*(\w+)\s*\}\}/,
      a = e || this.money_format;

  switch (a.match(n)[1]) {
    case "amount":
      r = i(t, 2);
      break;

    case "amount_no_decimals":
      r = i(t, 0);
      break;

    case "amount_with_comma_separator":
      r = i(t, 2, ".", ",");
      break;

    case "amount_with_apostrophe_separator":
      r = i(t, 2);
      break;

    case "amount_no_decimals_with_comma_separator":
      r = i(t, 0, ".", ",");
      break;

    case "amount_no_decimals_with_space_separator":
      r = i(t, 0, ".", " ");
  }

  return a.replace(n, r);
}, Shopify.OptionSelectors = function (t, e) {
  return this.selectorDivClass = "selector-wrapper", this.selectorClass = "single-option-selector", this.variantIdFieldIdSuffix = "-variant-id", this.variantIdField = null, this.historyState = null, this.selectors = [], this.domIdPrefix = t, this.product = new Shopify.Product(e.product), this.onVariantSelected = Shopify.isDefined(e.onVariantSelected) ? e.onVariantSelected : function () {}, this.replaceSelector(t), this.initDropdown(), e.enableHistoryState && (this.historyState = new Shopify.OptionSelectors.HistoryState(this)), !0;
}, Shopify.OptionSelectors.prototype.initDropdown = function () {
  var t = {
    initialLoad: !0
  },
      e = this.selectVariantFromDropdown(t);

  if (!e) {
    var o = this;
    setTimeout(function () {
      o.selectVariantFromParams(t) || o.fireOnChangeForFirstDropdown.call(o, t);
    });
  }
}, Shopify.OptionSelectors.prototype.fireOnChangeForFirstDropdown = function (t) {
  this.selectors[0].element.onchange(t);
}, Shopify.OptionSelectors.prototype.selectVariantFromParamsOrDropdown = function (t) {
  var e = this.selectVariantFromParams(t);
  e || this.selectVariantFromDropdown(t);
}, Shopify.OptionSelectors.prototype.replaceSelector = function (t) {
  var e = document.getElementById(t),
      o = e.parentNode;
  Shopify.each(this.buildSelectors(), function (t) {
    o.insertBefore(t, e);
  }), e.style.display = "none", this.variantIdField = e;
}, Shopify.OptionSelectors.prototype.selectVariantFromDropdown = function (t) {
  var e = document.getElementById(this.domIdPrefix).querySelector("[selected]");
  if (e || (e = document.getElementById(this.domIdPrefix).querySelector('[selected="selected"]')), !e) return !1;
  var o = e.value;
  return this.selectVariant(o, t);
}, Shopify.OptionSelectors.prototype.selectVariantFromParams = function (t) {
  var e = Shopify.urlParam("variant");
  return this.selectVariant(e, t);
}, Shopify.OptionSelectors.prototype.selectVariant = function (t, e) {
  var o = this.product.getVariantById(t);
  if (null == o) return !1;

  for (var i = 0; i < this.selectors.length; i++) {
    var r = this.selectors[i].element,
        n = r.getAttribute("data-option"),
        a = o[n];
    null != a && this.optionExistInSelect(r, a) && (r.value = a);
  }

  return "undefined" != typeof jQuery ? jQuery(this.selectors[0].element).trigger("change", e) : this.selectors[0].element.onchange(e), !0;
}, Shopify.OptionSelectors.prototype.optionExistInSelect = function (t, e) {
  for (var o = 0; o < t.options.length; o++) {
    if (t.options[o].value == e) return !0;
  }
}, Shopify.OptionSelectors.prototype.insertSelectors = function (t, e) {
  Shopify.isDefined(e) && this.setMessageElement(e), this.domIdPrefix = "product-" + this.product.id + "-variant-selector";
  var o = document.getElementById(t);
  Shopify.each(this.buildSelectors(), function (t) {
    o.appendChild(t);
  });
}, Shopify.OptionSelectors.prototype.buildSelectors = function () {
  for (var t = 0; t < this.product.optionNames().length; t++) {
    var e = new Shopify.SingleOptionSelector(this, t, this.product.optionNames()[t], this.product.optionValues(t));
    e.element.disabled = !1, this.selectors.push(e);
  }

  var o = this.selectorDivClass,
      i = this.product.optionNames(),
      r = Shopify.map(this.selectors, function (t) {
    var e = document.createElement("div");

    if (e.setAttribute("class", o), i.length > 1) {
      var r = document.createElement("label");
      r.htmlFor = t.element.id, r.innerHTML = t.name, e.appendChild(r);
    }

    return e.appendChild(t.element), e;
  });
  return r;
}, Shopify.OptionSelectors.prototype.selectedValues = function () {
  for (var t = [], e = 0; e < this.selectors.length; e++) {
    var o = this.selectors[e].element.value;
    t.push(o);
  }

  return t;
}, Shopify.OptionSelectors.prototype.updateSelectors = function (t, e) {
  var o = this.selectedValues(),
      i = this.product.getVariant(o);
  i ? (this.variantIdField.disabled = !1, this.variantIdField.value = i.id) : this.variantIdField.disabled = !0, this.onVariantSelected(i, this, e), null != this.historyState && this.historyState.onVariantChange(i, this, e);
}, Shopify.OptionSelectorsFromDOM = function (t, e) {
  var o = e.optionNames || [],
      i = e.priceFieldExists || !0,
      r = e.delimiter || "/",
      n = this.createProductFromSelector(t, o, i, r);
  e.product = n, Shopify.OptionSelectorsFromDOM.baseConstructor.call(this, t, e);
}, Shopify.extend(Shopify.OptionSelectorsFromDOM, Shopify.OptionSelectors), Shopify.OptionSelectorsFromDOM.prototype.createProductFromSelector = function (t, e, o, i) {
  if (!Shopify.isDefined(o)) var o = !0;
  if (!Shopify.isDefined(i)) var i = "/";
  var r = document.getElementById(t),
      n = r.childNodes,
      a = (r.parentNode, e.length),
      s = [];
  Shopify.each(n, function (t, r) {
    if (1 == t.nodeType && "option" == t.tagName.toLowerCase()) {
      var n = t.innerHTML.split(new RegExp("\\s*\\" + i + "\\s*"));
      0 == e.length && (a = n.length - (o ? 1 : 0));
      var p = n.slice(0, a),
          l = o ? n[a] : "",
          c = (t.getAttribute("value"), {
        available: t.disabled ? !1 : !0,
        id: parseFloat(t.value),
        price: l,
        option1: p[0],
        option2: p[1],
        option3: p[2]
      });
      s.push(c);
    }
  });
  var p = {
    variants: s
  };

  if (0 == e.length) {
    p.options = [];

    for (var l = 0; a > l; l++) {
      p.options[l] = "option " + (l + 1);
    }
  } else p.options = e;

  return p;
}, Shopify.SingleOptionSelector = function (t, e, o, i) {
  this.multiSelector = t, this.values = i, this.index = e, this.name = o, this.element = document.createElement("select");

  for (var r = 0; r < i.length; r++) {
    var n = document.createElement("option");
    n.value = i[r], n.innerHTML = i[r], this.element.appendChild(n);
  }

  return this.element.setAttribute("class", this.multiSelector.selectorClass), this.element.setAttribute("data-option", "option" + (e + 1)), this.element.id = t.domIdPrefix + "-option-" + e, this.element.onchange = function (o, i) {
    i = i || {}, t.updateSelectors(e, i);
  }, !0;
}, Shopify.Image = {
  preload: function preload(t, e) {
    for (var o = 0; o < t.length; o++) {
      var i = t[o];
      this.loadImage(this.getSizedImageUrl(i, e));
    }
  },
  loadImage: function loadImage(t) {
    new Image().src = t;
  },
  switchImage: function switchImage(t, e, o) {
    if (t && e) {
      var i = this.imageSize(e.src),
          r = this.getSizedImageUrl(t.src, i);
      o ? o(r, t, e) : e.src = r;
    }
  },
  imageSize: function imageSize(t) {
    var e = t.match(/_(1024x1024|2048x2048|pico|icon|thumb|small|compact|medium|large|grande)\./);
    return null != e ? e[1] : null;
  },
  getSizedImageUrl: function getSizedImageUrl(t, e) {
    if (null == e) return t;
    if ("master" == e) return this.removeProtocol(t);
    var o = t.match(/\.(jpg|jpeg|gif|png|bmp|bitmap|tiff|tif)(\?v=\d+)?$/i);

    if (null != o) {
      var i = t.split(o[0]),
          r = o[0];
      return this.removeProtocol(i[0] + "_" + e + r);
    }

    return null;
  },
  removeProtocol: function removeProtocol(t) {
    return t.replace(/http(s)?:/, "");
  }
}, Shopify.OptionSelectors.HistoryState = function (t) {
  this.browserSupports() && this.register(t);
}, Shopify.OptionSelectors.HistoryState.prototype.register = function (t) {
  window.addEventListener("popstate", function (e) {
    t.selectVariantFromParamsOrDropdown({
      popStateCall: !0
    });
  });
}, Shopify.OptionSelectors.HistoryState.prototype.onVariantChange = function (t, e, o) {
  this.browserSupports() && (!t || o.initialLoad || o.popStateCall || Shopify.setParam("variant", t.id));
}, Shopify.OptionSelectors.HistoryState.prototype.browserSupports = function () {
  return window.history && window.history.replaceState;
};
/*============================================================================
Product media controls
==============================================================================*/

Shopify.theme.productMedia = {
  models: [],
  setupMedia: function setupMedia() {
    var config = {
      // Default control list
      controls: ['zoom-in', 'zoom-out', 'fullscreen'],
      focusOnPlay: false
    };
    $('model-viewer').each(function (index, model) {
      model = new Shopify.ModelViewerUI(model, config);
      Shopify.theme.productMedia.models.push(model);
    });
    $('.product-gallery__model model-viewer').on('mousedown', function () {
      Shopify.theme.productMedia.hideModelIcon(this);
    });
  },
  showModelIcon: function showModelIcon(slide) {
    $(slide).find('.button--poster, .model-icon-button-control').show();
  },
  hideModelIcon: function hideModelIcon(slide) {
    $(slide).find('.button--poster, .model-icon-button-control').hide();
  }
};
Shopify.theme.productReviews = {
  init: function init() {
    if ($('#shopify-product-reviews').length || $('.shopify-product-reviews-badge').length) {
      SPR.$(document).ready(function () {
        return SPR.registerCallbacks(), SPR.initRatingHandler(), SPR.initDomEls(), SPR.loadProducts(), SPR.loadBadges();
      });
    }
  },
  productReviewScroll: function productReviewScroll() {
    if ($('#shopify-product-reviews').length && $('.shopify-product-reviews-badge').length) {
      $('.spr-badge-container').on('click', function () {
        Shopify.theme.scrollToTop('#shopify-product-reviews');
      });
    }
  },
  unload: function unload() {
    $('.spr-badge-container').off();
  }
};
Shopify.theme.quantityBox = {
  init: function init() {
    $('body').on('click', '[data-update-quantity]:not([disabled])', function () {
      Shopify.theme.quantityBox.updateQuantity($(this));
    });
    $('body').on('keyup keydown change', '.quantity-input', function () {
      Shopify.theme.quantityBox.updateQuantity($(this));
    });
  },
  updateQuantityControls: function updateQuantityControls($el) {
    var $quantityBox = $el.parents('.product-quantity-box');
    var $input = $('.quantity-input', $quantityBox);
    var val = parseInt($input.val());
    var valMax = 100000000000000000;

    if ($input.attr('max') != null) {
      valMax = $input.attr('max');
    }

    if (val === 1 || val === 0) {
      $('.quantity-minus', $quantityBox).attr('disabled', true);
      $('.quantity-plus', $quantityBox).attr('disabled', false);
    } else if (val >= valMax) {
      $('.quantity-plus', $quantityBox).attr('disabled', true);
      $('.quantity-minus', $quantityBox).attr('disabled', false);
      $input.val(valMax);
    } else {
      $('.quantity-minus', $quantityBox).attr('disabled', false);
      $('.quantity-plus', $quantityBox).attr('disabled', false);
    }
  },
  updateQuantity: function updateQuantity($el) {
    var $quantityBox = $el.parents('.product-quantity-box');
    var $input = $('.quantity-input', $quantityBox);
    var lineID = $quantityBox.parents('[data-line-item]').data('line-item');
    var val = parseInt($input.val());
    var valMax = 100000000000000000;
    var valMin = $input.attr('min') || 0;

    if ($input.attr('max') != null) {
      valMax = $input.attr('max');
    }

    if (isNaN(val) || val < valMin) {
      $input.val(valMin);
      return false;
    } else if (val > valMax) {
      $input.val(valMax);
      return false;
    }

    if ($el.data('update-quantity') === 'plus') {
      // Increase quantity input by one
      if (val < valMax) {
        val++;
        $input.val(val);
      }
    } else if ($el.data('update-quantity') === 'minus') {
      // Decrease quantity by one
      if (val > valMin) {
        val--;
        $input.val(val);
      }
    } // Update quantity if within cart (vs on the product page)


    if ($el.parents('[data-line-item]').length) {
      var _lineID = $quantityBox.data('line-item-key');

      Shopify.theme.quantityBox.updateCart(_lineID, val);
    } // Call to update quantity controls


    Shopify.theme.quantityBox.updateQuantityControls($el);
  },
  updateCart: function updateCart(lineID, quantity) {
    $('.quantity-warning').removeClass('animated bounceIn');
    $.ajax({
      type: 'POST',
      url: '/cart/change.js',
      data: "quantity=".concat(quantity, "&line=").concat(lineID),
      dataType: 'json',
      success: function success(cart) {
        var newQuantity = 0;
        var itemsLeftText = '';
        var quantityWarning = $("[data-line-item=\"".concat(lineID, "\"]")).find('.quantity-warning');
        var $quantityBox = $("[data-line-item=\"".concat(lineID, "\"]")).find('.product-quantity-box');
        var $currentDiscount = $('.cart__form').data('currentDiscount'); //check to see if there are correct amount of products in array

        var cartItemsLineID = lineID - 1;

        if (typeof cart.items[cartItemsLineID] !== "undefined") {
          newQuantity = cart.items[cartItemsLineID].quantity;
        }

        for (var _i3 = 0; _i3 < cart.items.length; _i3++) {
          if (_i3 != cartItemsLineID) {
            if (cart.items[_i3].id == cart.items[cartItemsLineID].id) {
              newQuantity += cart.items[_i3].quantity;
            }
          }
        }

        if (quantity > 0 && quantity != newQuantity) {
          //Check if total discount has changed
          if (cart.total_discount <= $currentDiscount) {
            if (newQuantity == 1) {
              itemsLeftText = Shopify.translation.product_count_one;
              quantityWarning.text("".concat(newQuantity, " ").concat(itemsLeftText));
              $('.quantity-minus', $quantityBox).attr('disabled', true);
            } else {
              itemsLeftText = Shopify.translation.product_count_other;
              quantityWarning.text("".concat(newQuantity, " ").concat(itemsLeftText));
            }
          }
        } //Update total discount value


        $('.cart__form').data('currentDiscount', cart.total_discount); // Apply quantity warning

        quantityWarning.addClass('animated bounceIn');

        if (typeof Shopify.theme.jsAjaxCart !== 'undefined') {
          Shopify.theme.jsAjaxCart.updateView();
        }

        if (Shopify.theme.jsCart) {
          Shopify.theme.jsCart.updateView(cart, lineID);
        }
      },
      error: function error(XMLHttpRequest, textStatus) {
        var response = eval('(' + XMLHttpRequest.responseText + ')');
        response = response.description;
      }
    });
  },
  unload: function unload($target) {
    $('.quantity-input').off();
    $('[data-update-quantity]').off();
  }
};
Shopify.theme.queryParameters = {};

if (location.search.length) {
  for (var aKeyValue, i = 0, aCouples = location.search.substr(1).split('&'); i < aCouples.length; i++) {
    aKeyValue = aCouples[i].split('=');

    if (aKeyValue.length > 1) {
      Shopify.theme.queryParameters[decodeURIComponent(aKeyValue[0])] = decodeURIComponent(aKeyValue[1]);
    }
  }
}

Shopify.theme.responsiveVideo = {
  init: function init() {
    // Find youtube iframes
    var $videoIframes = $('iframe[src*="youtube.com"], iframe[src*="vimeo.com"]'); // For each iframe, if parent is a responsive video wrapper do nothing
    // If no parent responsive video wrapper, then wrap iframe in responsive video wrapper

    $videoIframes.each(function (index, iframe) {
      // Update selector
      var $iframe = $(iframe);

      if (!$iframe.parents('.plyr__video-wrapper').length && !$iframe.parents('.lazyframe').length) {
        $iframe.wrap('<div class="lazyframe" data-ratio="16:9"></div>');
      }
    });
  }
};

var selectCallback = function selectCallback(variant, selector) {
  var $product = $('.product-' + selector.product.id);
  var $notify_form = $('.notify-form-' + selector.product.id);
  var $productForm = $('.product_form, .shopify-product-form', $product);
  var variantInventory = $productForm.data('variant-inventory');
  var $productFormInput = $productForm.find('.quantity-input');
  var $notifyFormInputs = $('.notify_form__inputs');
  var notifyEmail = Shopify.translation.notify_form_email;
  var notifyEmailValue = Shopify.translation.contact_email;
  var notifySend = Shopify.translation.notify_form_send;
  var notifyUrl = $notifyFormInputs.data('url');

  if (variant) {
    if (variant.title != null) {
      // Escape variant titles
      var variantTitle = variant.title.replace(/"/g, '\&quot;');
      var notifyMessage = Shopify.translation.email_content + variantTitle + ' | ' + notifyUrl + '?variant=' + variant.id;
    }
  } else {
    var notifyMessage = Shopify.translation.email_content + ' | ' + notifyUrl;
  }

  if ($notifyFormInputs.hasClass('customer--true')) {
    var notifyCustomerEmail = Shopify.translation.customer_email;
    var notifyEmailInput = "\n      <input type=\"hidden\" class=\"notify_email input\" name=\"contact[email]\" id=\"contact[email]\" value=\"".concat(notifyCustomerEmail, "\" />");
  } else {
    var notifyEmailInput = "\n      <input required type=\"email\" class=\"notify_email input\" name=\"contact[email]\" id=\"contact[email]\" placeholder=\"".concat(notifyEmail, "\" value=\"").concat(notifyEmailValue, "\" />");
  }

  var notifyFormHTML = "\n    <input type=\"hidden\" name=\"challenge\" value=\"false\" />\n    <input type=\"hidden\" name=\"contact[body]\" class=\"notify_form_message\" data-body=\"".concat(notifyMessage, "\" value=\"").concat(notifyMessage, "\" />\n    <div class=\"field has-addons\">\n      <div class=\"control\">\n        ").concat(notifyEmailInput, "\n      </div>\n      <div class=\"control\">\n        <input class=\"action_button button\" type=\"submit\" value=\"").concat(notifySend, "\" />\n      </div>\n    </div>"); //Image Variant feature

  if (variant && variant.featured_image && $product.is(":visible")) {
    var $sliders = $('.product-gallery__main, .js-gallery-modal', $product);
    $sliders.each(function () {
      var $slider = $(this);
      var $sliderInstance = Flickity.data(this);
      var index = $("img[data-image-id=".concat(variant.featured_media.id, "]")).data('index');

      if ($slider.is(":visible") && $sliderInstance != undefined) {
        $sliderInstance.select(index, false, true);
      }

      ;
    });
  } // Emits custom event


  var $selectDropdown = $productForm.find('[data-variant-selector]');
  $selectDropdown.trigger('selectedVariantChanged');

  if (variant) {
    if (variantInventory) {
      variantInventory.forEach(function (v) {
        if (v.id === variant.id) {
          variant.inventory_quantity = v.inventory_quantity;
          variant.inventory_management = v.inventory_management;
          variant.inventory_policy = v.inventory_policy;
        }
      });
    }

    $('.sku', $product).text(variant.sku);

    if (Shopify.theme_settings.product_form_style) {
      for (var i = 0, length = variant.options.length; i < length; i++) {
        var radioButton = $productForm.find('.swatch[data-option-index="' + escape(i) + '"] :radio[value="' + variant.options[i].replace(/\"/g, '\\"') + '"]');

        if (radioButton.length) {
          radioButton.get(0).checked = true;
        }
      }
    } else {
      $(".notify_form_message", $product).attr("value", $(".notify_form_message", $product).data('body') + " - " + variant.title);
    }
  }

  if (variant && variant.available == true) {
    if (variant.price < variant.compare_at_price) {
      $('.was-price', $product).html('<span class="money">' + Shopify.formatMoney(variant.compare_at_price, $('body').data('money-format')) + '</span>');
      $('.savings', $product).html(Shopify.translation.product_savings + ' ' + parseInt((variant.compare_at_price - variant.price) * 100 / variant.compare_at_price) + '% (' + '<span class="money">' + Shopify.formatMoney(variant.compare_at_price - variant.price, $('body').data('money-format')) + '</span>)');
      $('.current_price', $product).parent().addClass('sale');
    } else {
      $('.was-price', $product).html('');
      $('.savings', $product).html('');
      $('.current_price', $product).parent().removeClass('sale');
    }

    if (variant.inventory_management && variant.inventory_quantity > 0) {
      if (Shopify.theme_settings.display_inventory_left) {
        var items_left_text = Shopify.translation.product_count_other;

        if (variant.inventory_quantity == 1) {
          items_left_text = Shopify.translation.product_count_one;
        }

        var inventoryThreshold = Shopify.theme_settings.inventory_threshold;

        if (variant.inventory_quantity <= inventoryThreshold) {
          $('.items_left', $product).html(variant.inventory_quantity + " " + items_left_text);
        } else {
          $('.items_left', $product).html("");
        }
      }

      if (variant.inventory_policy == "deny") {
        $('[data-max-inventory-management]', $product).attr('max', variant.inventory_quantity); // Check to see if quantity selector should be disabled based on inventory remaining

        Shopify.theme.quantityBox.updateQuantityControls($productFormInput);
      }
    } else {
      $('.items_left', $product).text('');
      $('[data-max-inventory-management]', $product).removeAttr('max');
    }

    $('.sold_out', $product).text('');
    $('.cart-warning', $product).text('');

    if (variant.price > 0) {
      $('.current_price', $product).html('<span class="money">' + Shopify.formatMoney(variant.price, $('body').data('money-format')) + '</span>');
    } else {
      $('.current_price', $product).html(Shopify.translation.free_price_text);
    }

    $('[data-add-to-cart-trigger]', $product).removeClass('disabled').removeAttr('disabled').find('span:not(.icon)').text($('[data-add-to-cart-trigger]', $product).data('label'));
    $('.shopify-payment-button', $product).show();
    $('.purchase-details__quantity', $product).show();
    $notify_form.hide();
    $notifyFormInputs.empty();
    $notifyFormInputs.append(notifyFormHTML);

    if (Currency.show_multiple_currencies) {
      Shopify.theme.currencyConverter.convertCurrencies();
    }
  } else {
    var message = variant ? Shopify.translation.soldOut : Shopify.translation.unavailable;
    $('.was-price', $product).text('');
    $('.savings', $product).text('');
    $('.current_price', $product).text('');
    $('.items_left', $product).text('');
    $('[data-max-inventory-management]', $product).removeAttr('max');
    $('.sold_out', $product).text(message);
    $('[data-add-to-cart-trigger]', $product).addClass('disabled').attr('disabled', 'disabled').find('span:not(.icon)').text(message);
    $('.shopify-payment-button', $product).hide();
    $('.purchase-details__quantity', $product).hide();
    $notify_form.hide();
    $notifyFormInputs.empty();

    if (variant && !variant.available) {
      $notify_form.fadeIn();
      $notifyFormInputs.empty();
      $notifyFormInputs.append(notifyFormHTML);
    }
  }
};

Shopify.theme.predictiveSearch = {
  vars: {
    term: '',
    searchPath: Shopify.routes.search_url,
    displayTimer: ''
  },
  init: function init() {
    this.unload();
    $('[data-show-search-trigger], [data-autocomplete-true] input').on('click touchstart', function (e) {
      if (!isScreenSizeLarge()) {
        e.stopPropagation();
        var formType = $(this).closest('form').find('[name="type"]').val();
        var position = $(document).scrollTop();
        Shopify.theme.predictiveSearch.showMobileSearch(formType, position);
      }
    }); // Focus state to display search results

    $('[data-autocomplete-true]').on('focus', function () {
      $(this).parents('[data-autocomplete-true]').find('.search__results-wrapper').show();
    }); // Clicking outside makes the results disappear.

    $(document).on('click focusout', function (e) {
      if (Shopify.media_queries.large.matches) {
        var searchForm = $(e.target).parents('.search-form');

        if (searchForm.length === 0) {
          $('[data-autocomplete-true] .search__results-wrapper').hide().removeClass('results-found');
        }
      }
    }); // Submit wildcard searches

    $("[data-autocomplete-true] form").on("submit", function (e) {
      e.preventDefault();
      var formValue = $(this).find('input[name="q"]').val();
      var cleanFormValue = encodeURI(formValue);
      var searchType = Shopify.theme_settings.search_option;

      if ($(this).find('[name="type"]').length > 0) {
        searchType = $(this).find('[name="type"]').val();
      }

      if (cleanFormValue == null) {
        window.location.href = Shopify.routes.search_url + '?type=' + searchType;
      } else {
        window.location.href = Shopify.theme.predictiveSearch.vars.searchPath + '?type=' + searchType + '&q=' + cleanFormValue + '*';
      }
    });
    $('[data-autocomplete-true] form').each(function () {
      var $this = $(this);
      var input = $this.find('input[name="q"]'); // Adding a list for showing search results.

      var resultWrapper = "\n        <div class=\"search__results-wrapper\">\n          <h2 class=\"vertical-search__title\">\n            ".concat(Shopify.translation.top_suggestions, "\n          </h2>\n          <ul class=\"search__results\"></ul>\n        </div>\n      ");
      $(resultWrapper).appendTo($this);
      input.attr('autocomplete', 'off').on('input', function () {
        clearTimeout(Shopify.theme.predictiveSearch.vars.displayTimer);

        if ($(this).val().length > 3) {
          Shopify.theme.predictiveSearch.vars.term = $(this).val();
          Shopify.theme.predictiveSearch.getResults(Shopify.theme.predictiveSearch.vars.term, $this);
        } else {
          $('[data-autocomplete-true] .search__results-wrapper').hide().removeClass('results-found');
        }
      });
    });
  },
  getResults: function getResults(term, $this) {
    var searchType = Shopify.theme_settings.search_option;

    if ($this.find('[name="type"]').length > 0) {
      searchType = $this.find('[name="type"]').val();
    }

    jQuery.getJSON("/search/suggest.json", {
      "q": term,
      "resources": {
        "type": searchType,
        "limit": Shopify.theme_settings.search_to_display,
        "options": {
          "unavailable_products": "last",
          "fields": "title,body,variants.title,vendor,product_type,tag"
        }
      }
    }).done(function (response) {
      var suggestions = [response.resources.results.products, response.resources.results.pages, response.resources.results.articles];
      var filteredResults = []; // Store results in array

      $.each(suggestions, function (index, suggestion) {
        if (suggestion !== undefined && suggestion.length > 0) {
          // Ensure suggestion exists
          filteredResults.push(suggestion);
        }
      }); // Display results

      Shopify.theme.predictiveSearch.vars.displayTimer = setTimeout(function () {
        Shopify.theme.predictiveSearch.displayResults(filteredResults[0], $this);
      }, 500);
    });
  },
  displayResults: function displayResults(results, $this) {
    var $resultsWrapper = $this.find('.search__results-wrapper');
    var $resultsList = $this.find('.search__results');
    var searchType = Shopify.theme_settings.search_option;
    $resultsWrapper.show();
    $resultsList.empty();

    if ($this.find('[name="type"]').length > 0) {
      searchType = $this.find('[name="type"]').val();
    }

    if (results && results.length > 0) {
      $.each(results, function (index, result) {
        var link = $('<a tabindex="0"></a>').attr('href', result.url);

        if (Shopify.routes.root_url !== '/') {
          link = $('<a tabindex="0"></a>').attr('href', Shopify.routes.root_url + result.url);
        } // if result is a product


        if (result['price']) {
          var formatPrice = function formatPrice(price) {
            if (Currency.display_format === 'money_with_currency_format') {
              return "<span class=\"money\"> ".concat(Currency.symbol + price, " ").concat(Currency.iso_code, " </span>");
            } else {
              return "<span class=\"money\"> ".concat(Currency.symbol + price, " </span>");
            }
          };

          var itemPrice;

          if (result.available === true) {
            if (result.compare_at_price_max > result.price_max || result.compare_at_price_min > result.price_min) {
              itemPrice = "".concat(formatPrice(result.price), " <span class=\"was-price\">").concat(formatPrice(result.compare_at_price_max), "</span>");
            } else {
              if (result.price > 0) {
                if (result.price_min != result.price_max) {
                  itemPrice = "".concat(Shopify.translation.from, " ").concat(formatPrice(result.price));
                } else {
                  itemPrice = "".concat(formatPrice(result.price));
                }
              } else {
                itemPrice = Shopify.theme_settings.free;
              }
            }
          } else {
            itemPrice = Shopify.translation.soldOut;
          } // If result has image


          if (result['image']) {
            link.append("<div class=\"thumbnail\"><img class=\"lazyload transition--".concat(Shopify.theme_settings.image_loading_style, "\" src=\"").concat(Shopify.theme.addImageDimension(result['image'], '_300x'), "\" /></div>"));
          }

          link.append("<div class=\"description\"><strong>".concat(result.title, "</strong><br><span class=\"item-pricing price\">").concat(itemPrice, "</span></div>")); // if result is an article
        } else if (result['summary_html']) {
          if (result.image != 'NULL') {
            link.append("<div class=\"thumbnail\"><img class=\"lazyload transition--".concat(Shopify.theme_settings.image_loading_style, "\" src=\"").concat(Shopify.theme.addImageDimension(result['image'], '_300x'), "\" /></div>"));
          }

          link.append("<div class=\"description\"><strong>".concat(result.title, "</strong><br><span class=\"item-description\">'").concat(result.summary_html.replace(/(<([^>]+)>)/ig, "").slice(0, 25), "</span></div>")); // if result is a page
        } else if (result['published_at']) {
          link.append("<div class=\"description\"><strong>".concat(result.title, "</strong><br><span class=\"item-description\">").concat(result.body.replace(/(<([^>]+)>)/ig, "").slice(0, 25), "</span></div>"));
        } // Wrap link and append to list


        link.wrap('<li class="item-result"></li>');
        $resultsList.append(link.parent());

        if (Currency.show_multiple_currencies || Currency.native_multi_currency) {
          Shopify.theme.currencyConverter.init();
        }
      });
      $resultsList.prepend("<li class=\"all-results\"><span class=\"see-all\"><a href=\"".concat(this.vars.searchPath, "?type=").concat(searchType, "&q=").concat(this.vars.term, "*\"> ").concat(Shopify.translation.all_results, " ").concat(Shopify.icons.right_caret, "</a></span></li>"));
      $resultsList.parents('.search__results-wrapper').addClass('results-found');
    } else {
      // if no results
      var noResults = "<li class=\"item-result\"><span class=\"no-results\">".concat(Shopify.translation.no_results, "</span></li>");
      $resultsList.append(noResults);
      $resultsList.parents('.search__results-wrapper').removeClass('results-found');
    }

    if ($this.parents('.vertical-header__content').length && Shopify.theme.jsHeader.header_layout === 'vertical') {
      Shopify.theme.predictiveSearch.alignVerticalSearch();
    }

    $resultsList.show();
  },
  showMobileSearch: function showMobileSearch(formType, position) {
    $('body').css('max-height', window.innerHeight);
    $('.mobile-search').fadeIn(200);

    if (/iPad|iPhone|iPod/.test(navigator.platform) || navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1) {
      $('.mobile-search input#q').focus();
    } else {
      //Set delay to ensure focus triggers on android
      setTimeout(function () {
        $('.mobile-search input#q').focus();
      }, 205);
    }

    document.body.style.position = 'fixed';
    document.body.style.top = '-' + position + 'px';
    $('.mobile-search').css('top', position);
    var searchHeight = window.innerHeight - 46; //Full screen height - form height

    $('.mobile-search .search__results-wrapper').css('max-height', searchHeight);

    if (formType) {
      $('.mobile-search [name="type"]').val(formType);
    } else {
      $('.mobile-search [name="type"]').val(Shopify.theme_settings.search_option);
    }

    $('.search-form .close-search').on('click touchstart', function (e) {
      e.preventDefault();
      e.stopPropagation();
      Shopify.theme.predictiveSearch.hideMobileSearch(position);
      $('[data-autocomplete-true] .search__results-wrapper').hide().removeClass('results-found');
    });
    $('.search-form .submit-search').on('click touchstart', function (e) {
      $(this).parents('form').submit();
    });
  },
  hideMobileSearch: function hideMobileSearch(position) {
    $('body').css('max-height', 'none');
    document.body.style.position = '';
    document.body.style.top = '';
    window.scrollTo(0, position);
    $('.mobile-search').fadeOut(200);
    $('.mobile-search [name="q"]').val('');
    $('body').off('focus', '.search-form .close-search');
    $('body').off('focus', '.search-form .submit-search');
  },
  alignVerticalSearch: function alignVerticalSearch() {
    var $resultsList = $('.header--vertical .search__results');
    var headerWidth = $('.header--vertical').innerWidth();
    $resultsList.parents('.search__results-wrapper').css({
      'position': 'fixed',
      'left': headerWidth,
      'top': '0'
    });
  },
  unload: function unload() {
    $('body').off('focus', '[data-autocomplete-true] input');
    $('input[name="q"]').off();
    $('[data-dropdown-rel="search"], [data-autocomplete-true] input').off();
    $('.search__results-wrapper').remove();
  }
};

function isScreenSizeLarge() {
  if (Shopify.media_queries.large.matches) {
    return true;
  }
}

Shopify.theme.scrollToTop = function (element, height) {
  // Check if height argument is present
  if (height != undefined) {
    $('html, body').animate({
      scrollTop: $(element).offset().top - height
    }, 1000);
  } else {
    $('html, body').animate({
      scrollTop: $(element).offset().top
    }, 1000);
  }
};

Shopify.theme.tabs = {
  enableTabs: function enableTabs() {
    var $tabs = $('.tabs li, .tabs li a');
    $tabs.on('click', function (el) {
      el.preventDefault(); // toggle active tab

      $tabs.removeClass('is-active active');
      $(this).addClass('is-active');
      var $tabIndex = $(this).index();
      var $tabContent = $(this).parents('.tabs').next('.tabs-content'); // toggle corresponding tab content

      $tabContent.children('li, li a').removeClass('is-active active');
      $tabContent.children('li, li a').eq($tabIndex).addClass('is-active').show().css({
        'display': 'block'
      }).siblings().hide().removeClass('is-active');
    });
  },
  unload: function unload() {
    $('.tabs li, .tabs li a').off();
  }
};
var globalQuickShopProduct;
Shopify.theme.thumbnail = {
  enableSwatches: function enableSwatches() {
    if (isScreenSizeLarge()) {
      $('body').on('mouseenter', '.swatch span', function () {
        if ($(this).data('image').indexOf('no-image') == -1) {
          $(this).parents('.thumbnail').find('.product__imageContainer img:not(.secondary)').attr('src', $(this).data('image'));
          $(this).parents('.thumbnail').find('.product__imageContainer img:not(.secondary)').attr('srcset', $(this).data('image'));
        }
      });
    }
  },
  showVariantImage: function showVariantImage() {
    if (isScreenSizeLarge()) {
      $('body').on('mouseenter', '.has-secondary-image-swap', function () {
        var $thumbnailImage = $(this).find('.product-image__wrapper img');
        var $thumbnailVideo = $(this).find('.product-image__wrapper .video-on-hover');

        if ($thumbnailImage) {
          $thumbnailImage.toggleClass('swap--visible');
        }

        if ($thumbnailVideo) {
          $thumbnailVideo.toggleClass('swap--visible');
          Shopify.theme.video.enableVideoOnHover($(this));
        }
      });
      $('body').on('mouseleave', '.has-secondary-image-swap', function () {
        var $thumbnailImage = $(this).find('.product-image__wrapper img');
        var $thumbnailVideo = $(this).find('.product-image__wrapper .video-on-hover');

        if ($thumbnailImage) {
          $thumbnailImage.toggleClass('swap--visible');
        }

        if ($thumbnailVideo) {
          $thumbnailVideo.toggleClass('swap--visible');
          Shopify.theme.video.disableVideoOnHover($(this));
        }
      });
    }
  },
  showQuickShop: function showQuickShop() {
    //EVENT - click on quick-shop
    $('body').on('click', '.js-quick-shop-link', function (e) {
      e.preventDefault(); //Set productData object based on data attributes

      var productData = {
        handle: $(this).data('handle'),
        product_id: $(this).data('id'),
        single_variant: $(this).attr('data-single-variant'),
        product_in_collection_url: $(this).data('url'),
        escaped_title: $(this).data('title'),
        details_text: $(this).data('details-text'),
        full_description: $(this).data('full-description'),
        regular_description: $(this).data('regular-description'),
        featured_image: $(this).data('featured-image'),
        image_array: Shopify.theme.thumbnail.createImageObjects($(this).data('images')),
        thumbnail_array: Shopify.theme.thumbnail.createImageObjects($(this).data('thumbnail-images')),
        collection_handles: $(this).data('collection-handles').trim(',').split(','),
        money_format: $('body').data('money-format')
      }; //Find current product and notify forms

      var $notifyForm = $(this).next('.js-quickshop-forms__container').find('.notify_form');
      var $productForm = $(this).next('.js-quickshop-forms__container').find('.product_form');

      if (!$('.fancybox-active').length) {
        $.fancybox.open($('.js-quick-shop'), {
          baseClass: 'quick-shop__lightbox product-' + productData.product_id,
          hash: false,
          infobar: false,
          toolbar: false,
          loop: true,
          smallBtn: true,
          touch: false,
          video: {
            autoStart: false
          },
          mobile: {
            preventCaptionOverlap: false,
            toolbar: true
          },
          beforeLoad: function beforeLoad(instance, slide) {
            // Use unique identifier for the product gallery
            var src = slide.src;
            var $quickshop = $(src).find('.quick-shop');

            if (!$quickshop.hasClass('content-loaded')) {
              Shopify.theme.thumbnail.beforeOpen(productData, $quickshop);
            }
          },
          afterLoad: function afterLoad(instance, slide) {
            Shopify.theme.thumbnail.afterContent($productForm, $notifyForm, productData, slide);
            Shopify.theme.jsProduct.enableProductSwatches();
            Shopify.theme.productMedia.setupMedia();

            if (Currency.show_multiple_currencies) {
              Shopify.theme.currencyConverter.convertCurrencies();
            }
          },
          afterShow: function afterShow(e, instance) {
            if ($('.tabs').length > 0) {
              Shopify.theme.tabs.enableTabs();
            } // Use unique identifier for the product gallery


            var src = instance.src;
            var $quickshop = $(src).find('.quick-shop');
            $quickshop.addClass('quick-shop--loaded');
          },
          beforeClose: function beforeClose(e, instance) {
            // Use unique identifier for the product gallery
            var src = instance.src;
            var $quickshop = $(src).find('.quick-shop');
            Shopify.theme.thumbnail.beforeClose(productData, $quickshop);
            $quickshop.removeClass('quick-shop--loaded');
            $('body').removeClass('model-loaded');
          }
        });
      }
    });
  },
  beforeClose: function beforeClose(productData, $quickshop) {
    var $quickshopPopup = $quickshop.closest('.js-quick-shop');
    $quickshopPopup.removeClass('content-loaded');
    var $insertedNotifyForm = $('.quick-shop__lightbox .notify_form');
    var $insertedProductForm = $('.quick-shop__lightbox .product_form'); // Copy form data back to product loop and add .viewed

    $(".js-quickshop-forms--".concat(productData.product_id)).append($insertedProductForm);
    $(".js-quickshop-forms--".concat(productData.product_id)).append($insertedNotifyForm);
    $(".js-quickshop-forms--".concat(productData.product_id, " .product_form")).addClass('viewed');
    $(".js-quickshop-forms--".concat(productData.product_id, " .notify_form")).addClass('viewed'); // Clear stickers

    $('.quick-shop .thumbnail-sticker span').empty().parent().addClass('is-hidden'); // Find gallery and carousel

    var $gallery = $quickshop.find('.js-gallery-modal');
    var $carousel = $quickshop.find('.js-gallery-carousel');
    $carousel.find('.gallery-cell').off('click'); // Remove image slides from gallery

    $gallery.flickity('remove', $('.gallery-cell', $gallery));
    $carousel.empty(); // Can't use Flickity method on carousel because it can be both a slider/grid
    // Destroy sliders when modal closes

    $gallery.flickity('destroy');
    var variantPrice = $('.js-current-price .money').text();
    $(".js-quick-shop-link[data-id=".concat(productData.product_id, "]")).attr('data-initial-modal-price', variantPrice);
    $('.js-current-price, .js-was-price, .js-savings').empty();

    if ($gallery.data('enable-zoom') === true) {
      $gallery.trigger('zoom.destroy'); // remove zoom
    }
  },
  afterContent: function afterContent($productForm, $notifyForm, productData, slide) {
    // Locate unique identifier for the product gallery
    var src = slide.src;
    var $galleryModal = $(src).find('.js-gallery-modal');
    $galleryModal.closest('.js-quick-shop').addClass('content-loaded');
    Shopify.theme.thumbnail.retrieveProductInfo(productData);
    var settings = {
      thumbnailsEnabled: $galleryModal.data('thumbnails-enabled'),
      thumbnailsSliderEnabled: $galleryModal.data('thumbnails-slider-enabled'),
      thumbnailsPosition: $galleryModal.data('thumbnails-position'),
      arrowsEnabled: $galleryModal.data('gallery-arrows-enabled'),
      slideshowAnimation: $galleryModal.data('slideshow-animation'),
      slideshowSpeed: $galleryModal.data('slideshow-speed')
    }; // Call slideshow method from Product object

    Shopify.theme.jsProduct.enableSlideshow($galleryModal, settings); // Call Plyr to setup videos inside gallery

    Shopify.theme.video.init(); //Copy form data to modal

    $('.quick-shop__lightbox .js-notify-form').append($notifyForm);
    $('.quick-shop__lightbox .js-product-form').append($productForm); // Show the back in stock notification form

    $('.quick-shop__lightbox .modal_price, .quick-shop__lightbox .js-notify-form').show(); //Initiate selectCallback

    if ($productForm.hasClass("product_form_options") && !$productForm.hasClass("viewed")) {
      if ($('.select-container').length) {
        //If form hasn't been viewed previously, run OptionSelectors function
        new Shopify.OptionSelectors($productForm.data("select-id"), {
          product: $productForm.data("product"),
          onVariantSelected: selectCallback,
          enableHistoryState: $productForm.data("enable-state")
        });
      }
    } //Link sold out options when there is more than one option available (eg. S is selected and Yellow option appears as sold out)


    if (Shopify.theme_settings.product_form_style == 'swatches') {
      var JSONData = $productForm.data('product');
      var productID = productData.section_id;
      var productSection = '.product-' + productID + ' .js-product_section';
      var swatchOptions = $productForm.find('.swatch_options .swatch');

      if (swatchOptions.length > 1) {
        Shopify.linkOptionSelectors(JSONData, productSection);
      }
    }

    if ($('.single-option-selector').length > 0) {
      $('.selector-wrapper').wrap('<div class="select"></div>');
      $('#product-form-' + productData.product_id + ' .select-container').children().first().removeClass('select').addClass('select-container');
    }

    $('.js-quick-shop select[name="id"]').trigger('change');
  },
  createImageObjects: function createImageObjects($images) {
    //split image info
    var image_paths_alts = $images.split('~'); //Create new array with image objects

    var imageArray = image_paths_alts.map(function (image) {
      var imageInfo = image.split('^');
      return {
        path: imageInfo[0],
        alt: imageInfo[1],
        id: imageInfo[2],
        width: imageInfo[3],
        mediaType: imageInfo[4]
      };
    });
    return imageArray;
  },
  beforeOpen: function beforeOpen(productData, $quickshop) {
    //Add image elements before gallery is opened
    Shopify.theme.thumbnail.populateGallery(productData, $quickshop);
    $('.js-sale-sticker, .js-sold-out, .js-current-price, .js-was-price, .js-savings, .js-new-sticker, .js-pre-order-sticker').empty();
  },
  retrieveProductInfo: function retrieveProductInfo(productData) {
    $.ajax({
      dataType: "json",
      async: false,
      cache: false,
      url: "/products/" + productData.handle + ".js",
      success: function success(product) {
        //Create new object combining info
        product = $.extend({}, product, productData);
        globalQuickShopProduct = product;
        Shopify.theme.thumbnail.updateVariant(product.variants[0].id.toString(), product);
      }
    });
  },
  populateGallery: function populateGallery(productData, $quickshop) {
    //Find gallery and carousel
    var $gallery = $quickshop.find('.js-gallery-modal');
    var $carousel = $quickshop.find('.js-gallery-carousel'); //Add gallery images based on product info from API

    function addMainGalleryImages() {
      $.each(productData.image_array, function (i, image) {
        if (image.path == '' || image.id == undefined) {
          var imgPath = productData.featured_image;
          var alt = '';
        } else {
          var imgPath = image.path;
          var alt = image.alt;
        }

        var img2048x2048 = imgPath.replace(/(\.[^.]*)$/, "_2048x2048$1").replace('http:', '');
        var cellContent;

        if (image.mediaType.indexOf("image") >= 0) {
          cellContent = "\n            <div class=\"image__container\" style=\"max-width: ".concat(image.width, "px\">\n              <img src=\"").concat(imgPath, "\" alt=\"").concat(alt, "\" data-image-id=\"").concat(image.id, "\" data-index=\"").concat(i, "\" />\n            </div>\n          ");
        } else {
          cellContent = unescape(imgPath);
        }

        var $cellElems = $('<div class="gallery-cell">' + cellContent + '</div>');
        $gallery.append($cellElems);
      });
    } //Add carousel images based on product info from API


    function addCarouselGalleryImages() {
      $.each(productData.thumbnail_array, function (i, image) {
        if (image.path != '') {
          var imgPath = image.path;
          var carouselSizedImg = imgPath.replace(/(\.[^.]*)$/, "_grande$1").replace('http:', '');
          var mediaBadge = '';

          if (image.alt.indexOf("model") >= 0) {
            mediaBadge = '<span class="icon media-badge"><svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M1 25H25V1H1V25Z" fill=""/><path class="media-badge__outline" d="M0.5 25V25.5H1H25H25.5V25V1V0.5H25H1H0.5V1V25Z" stroke="" stroke-opacity="0.05"/><g opacity="0.6"><path fill-rule="evenodd" clip-rule="evenodd" d="M13 6L19.0622 9.5V16.5L13 20L6.93782 16.5V9.5L13 6Z" stroke="" stroke-width="1.5"/><path fill-rule="evenodd" clip-rule="evenodd" d="M13 20V12.6024C13.6225 12.2002 13.6225 12.2002 13.6225 12.2002L19 9V16.4082L13 20Z" fill=""/></g></svg></span>';
          } else if (image.alt.indexOf('external_video') >= 0 || image.alt.indexOf('video') >= 0) {
            mediaBadge = '<span class="icon media-badge"><svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M1 25H25V1H1V25Z" fill=""/><path class="media-badge__outline" d="M0.5 25V25.5H1H25H25.5V25V1V0.5H25H1H0.5V1V25Z" stroke="" stroke-opacity="0.05"/><path fill-rule="evenodd" clip-rule="evenodd" d="M8.19995 5.8V20.2L19.3999 12.5858L8.19995 5.8Z" fill="" fill-opacity="0.6"/></svg></span>';
          }

          var img = '<img src="' + carouselSizedImg + '" alt="' + escape(image.alt) + '" />';
          var $carouselCellElems = $('<div class="gallery-cell" tabindex="0">' + img + mediaBadge + '</div>');
          $carousel.append($carouselCellElems);
        }
      });
    }

    addMainGalleryImages(); // Only adds thumbnail images if they don't already exist
    // Also checks to make sure there is more than one slide in main gallery

    if ($carousel.find('.gallery-cell').length == 0 && $gallery.find('.gallery-cell').length > 1) {
      addCarouselGalleryImages();
    }

    if ($gallery.data('enable-zoom') === true) {
      $gallery.find('img').each(function (index, image) {
        $(image).wrap('<span class="zoom-container"></span>').css('display', 'block').parent().zoom({
          touch: false,
          magnify: 1
        });
      });
    }
  },
  updateVariant: function updateVariant(variant) {
    if (globalQuickShopProduct != 'undefined') {
      var getQuickShopInfo = function getQuickShopInfo(variant) {
        if (variant.id == variant.id.toString()) {
          //Sale sticker
          if (Shopify.theme_settings.stickers_enabled) {
            if (variant.compare_at_price > variant.price) {
              $('.sale-sticker span').html(Shopify.translation.sale).parent().removeClass('is-hidden');
            }
          } //Sale


          if (variant.compare_at_price > variant.price) {
            $('.js-current-price').addClass('sale');
          } else {
            $('.js-current-price').removeClass('sale');
          } //Availability


          if (variant.available == false) {
            if (product.collection_handles.indexOf('coming-soon') != -1) {
              // If product tags includes 'coming-soon', replace with Coming soon text
              if (!Shopify.theme_settings.stickers_enabled) {
                // Only show Coming soon text if stickers are disabled
                $('.js-sold-out').html(Shopify.translation.coming_soon);
              }
            } else {
              $('.js-sold-out').html(Shopify.translation.sold_out);
            }
          } else {
            $('.js-sold-out').html('');
          } //Price


          if (variant.available == true) {
            $('.js-notify-form').hide();

            if (variant.compare_at_price > variant.price) {
              $('.js-was-price').html('<span class="money">' + Shopify.formatMoney(variant.compare_at_price, product.money_format) + '</span>');
              $('.js-savings').html(Shopify.translation.savings + ' ' + parseInt((variant.compare_at_price - variant.price) * 100 / variant.compare_at_price) + '% (' + '<span class="money">' + Shopify.formatMoney(variant.compare_at_price - variant.price, product.money_format) + '</span>)');
            }

            if (product.price == Shopify.translation.coming_soon) {
              $('.js-current-price').html(Shopify.translation.coming_soon);
            } else if (variant.price) {
              $('.js-current-price').html('<span class="money">' + Shopify.formatMoney(variant.price, product.money_format) + '</span>');
            } else {
              $('.js-current-price').html(Shopify.translation.free_price_text);
            }
          } else {
            $('.js-notify-form').show();
          }
        }
      };

      var product = globalQuickShopProduct;
      $('.js-current-price').html('');
      $('.js-was-price').html('');
      $('.js-savings').html(''); //Title and Vendor

      $('.js-product-title').html('<a href="' + product.product_in_collection_url + '" title="' + product.escaped_title + '">' + product.title + '</a>');
      $('.js-product-vendor').html('<a href="/collections/vendors?q=' + product.vendor + '">' + product.vendor + '</a>'); //Product Description

      $('.js-full-description').html(product.full_description);
      $('.js-regular-description').html(product.regular_description);
      var productDetails = '<a href="' + product.product_in_collection_url + '" class="secondary_button" title="' + product.escaped_title + ' Details">' + product.details_text + '</a>';
      $('.js-product-details').html(productDetails); //Collection stickers

      if (Shopify.theme_settings.stickers_enabled) {
        $.each(product.collection_handles, function (value, index) {
          switch (this.toString()) {
            case 'best-seller':
              $('.best-seller-sticker span').html(Shopify.translation.best_seller).parent().removeClass('is-hidden');
              break;

            case 'coming-soon':
              $('.coming-soon-sticker span').html(Shopify.translation.coming_soon).parent().removeClass('is-hidden');
              break;

            case 'new':
              $('.new-sticker span').html(Shopify.translation.new_sticker).parent().removeClass('is-hidden');
              break;

            case 'pre-order':
              $('.pre-order-sticker span').html(Shopify.translation.pre_order).parent().removeClass('is-hidden');
              break;

            case 'staff-pick':
              $('.staff-pick-sticker span').html(Shopify.translation.staff_pick).parent().removeClass('is-hidden');
          }
        });
      }

      if (product.single_variant == 'true') {
        getQuickShopInfo(product);
      } else {
        for (var i = 0; i < product.variants.length; i++) {
          getQuickShopInfo(product.variants[i]);
        }
      }
    }
  }
};
var videoEl = {
  playButtonIcon: '<button type="button" class="plyr__control plyr__control--overlaid" aria-label="Play, {title}" data-plyr="play"><svg class="play-icon-button-control" width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg"><rect width="60" height="60" fill="white"/><path fill-rule="evenodd" clip-rule="evenodd" d="M23 20V40L39 29.4248L23 20Z" fill="#323232"/></svg><span class="plyr__sr-only">Play</span></button>',
  playButton: '<button type="button" class="plyr__controls__item plyr__control" aria-label="Play, {title}" data-plyr="play"><svg class="icon--pressed" role="presentation"><use xlink:href="#plyr-pause"></use></svg><svg class="icon--not-pressed" role="presentation"><use xlink:href="#plyr-play"></use></svg><span class="label--pressed plyr__tooltip" role="tooltip">Pause</span><span class="label--not-pressed plyr__tooltip" role="tooltip">Play</span></button>',
  muteButton: '<button type="button" class="plyr__controls__item plyr__control" aria-label="Mute" data-plyr="mute"><svg class="icon--pressed" role="presentation"><use xlink:href="#plyr-muted"></use></svg><svg class="icon--not-pressed" role="presentation"><use xlink:href="#plyr-volume"></use></svg><span class="label--pressed plyr__tooltip" role="tooltip">Unmute</span><span class="label--not-pressed plyr__tooltip" role="tooltip">Mute</span></button>',
  progressInput: '<div class="plyr__controls__item plyr__progress__container"><div class="plyr__progress"><input data-plyr="seek" type="range" min="0" max="100" step="0.01" value="0" aria-label="Seek"><progress class="plyr__progress__buffer" min="0" max="100" value="0">% buffered</progress><span role="tooltip" class="plyr__tooltip">00:00</span></div></div>',
  volume: '<div class="plyr__controls__item plyr__volume"><input data-plyr="volume" type="range" min="0" max="1" step="0.05" value="1" autocomplete="off" aria-label="Volume"></div>',
  fullscreen: '<button type="button" class="plyr__controls__item plyr__control" data-plyr="fullscreen"><svg class="icon--pressed" role="presentation"><use xlink:href="#plyr-exit-fullscreen"></use></svg><svg class="icon--not-pressed" role="presentation"><use xlink:href="#plyr-enter-fullscreen"></use></svg><span class="label--pressed plyr__tooltip" role="tooltip">Exit fullscreen</span><span class="label--not-pressed plyr__tooltip" role="tooltip">Enter fullscreen</span></button>'
};
var videoControls = "".concat(videoEl.playButtonIcon, "<div class=\"plyr__controls\"> ").concat(videoEl.playButton, " ").concat(videoEl.progressInput, " ").concat(videoEl.muteButton, " ").concat(videoEl.volume, " ").concat(videoEl.fullscreen, "</div>");
var videoPlayers = [];
var videosInRecommendedProductsPlayer;
Shopify.theme.video = {
  init: function init() {
    this.setupVideoPlayer();
  },
  setupVideoPlayer: function setupVideoPlayer() {
    var productVideos = document.querySelectorAll('[data-html5-video] video, [data-youtube-video]');
    var setupVideoPlayers = Plyr.setup(productVideos, {
      controls: videoControls,
      ratio: this.aspect_ratio,
      fullscreen: {
        enabled: true,
        fallback: true,
        iosNative: true
      },
      storage: {
        enabled: false
      }
    });
    var videoLooping = $('[data-video-loop]').data('video-loop') || false;
    $.each(setupVideoPlayers, function (index, player) {
      player.loop = videoLooping;
      videoPlayers.push(player);
    });
    this.setupListeners();
  },
  setupListeners: function setupListeners() {
    // Adds plyr video id to video wrapper
    $.each(videoPlayers, function (index, player) {
      var id = player.id;
      var $video;

      if (player.isHTML5) {
        $video = $(player.elements.wrapper).find('video');
        $video.attr('data-plyr-video-id', id);
      } // When a video is playing, pause any other instances


      player.on('play', function (event) {
        var instance = event.detail.plyr;
        $.each(videoPlayers, function (index, player) {
          var playerID = player.id || player.media.dataset.plyrVideoId;

          if (instance.id != playerID) {
            player.pause();
          }
        });
      });
    });
  },
  enableVideoOnHover: function enableVideoOnHover($thumbnail) {
    var $html5Video = $thumbnail.find('[data-html5-video]');
    var $youtubeVideo = $thumbnail.find('[data-youtube-video]');
    var videoID;

    if ($html5Video.length > 0) {
      videoID = $html5Video.find('[data-plyr-video-id]').data('plyr-video-id');
    } else if ($youtubeVideo.length > 0) {
      videoID = $youtubeVideo.find('iframe').attr('id');
    }

    if (videoID) {
      $.each(videoPlayers, function (index, player) {
        if (player.id == videoID || player.media.id == videoID) {
          player.toggleControls(false);
          player.muted = true;
          player.play();
        }
      });
    }
  },
  disableVideoOnHover: function disableVideoOnHover($thumbnail) {
    var $html5Video = $thumbnail.find('[data-html5-video]');
    var $youtubeVideo = $thumbnail.find('[data-youtube-video]');
    var videoID;

    if ($html5Video.length > 0) {
      videoID = $html5Video.find('[data-plyr-video-id]').data('plyr-video-id');
    } else if ($youtubeVideo.length > 0) {
      videoID = $youtubeVideo.find('iframe').attr('id');
    }

    if (videoID) {
      $.each(videoPlayers, function (index, player) {
        if (player.id == videoID || player.media.id == videoID) {
          if (player.playing) {
            player.pause();
          }
        }
      });
    }
  }
};